# MLN111 Study — Web ôn tập thông minh

## Dùng ngay
- Mở `index.html` trong Chrome, Edge hoặc Safari để học. Đây là web tĩnh, không cần cài đặt hay API key.
- Nếu trên iPhone trình xem file không chạy JavaScript, đưa thư mục lên một hosting tĩnh HTTPS (ví dụ GitHub Pages/Netlify) hoặc mở trong trình duyệt trên máy tính.
- File chính gồm cả dữ liệu và ảnh, không đòi hỏi Internet.

## Nội dung
- Đề 60 câu gần nhất: 60 câu từ MLN111 - 11_10.docx.
- Nhung Hoàng: 547 câu trích được trong tổng số 586 thẻ.
- Quizlet bổ sung: 182 câu trích được trong tổng số 528 thẻ.
- 13 ảnh không trùng hoàn toàn từ bộ ảnh đề trước đó.

## Chức năng
- Học từng câu, chấm ngay; thi thử không hiện đáp án trước khi nộp; flashcard.
- Ôn câu sai, lịch lặp lại (trả lời sai: 5 phút; đúng lần đầu: 1 ngày; đúng tiếp: 3 ngày; sau đó giãn dần), đánh dấu câu khó.
- Lọc theo nguồn, chủ đề gợi ý, tìm kiếm; thống kê.
- Tự lưu lịch sử theo trình duyệt bằng localStorage, có tải/xuất bản sao lưu JSON.
- Sửa khóa đáp án cá nhân, không sửa file gốc.

## Giới hạn và trung thực về nguồn
- Dữ liệu câu hỏi/khóa đáp án trích từ file đã tải lên; chưa thể cam kết đã đối chiếu từng câu với sách/slide.
- Câu 18, 28, 47, 50, 53 của đề 60 và một số câu Nhung Hoàng có ghi chú cần rà soát.
- File `questions.json` đính kèm là dữ liệu nguồn để bạn hoặc người phát triển tiếp tục chỉnh sửa. Khi chỉnh questions.json thì bản index.html độc lập không tự cập nhật; cần build lại/nhúng JSON mới.
- localStorage thường gắn với tên miền hoặc vị trí file. Nên sao lưu trước khi thay đổi trình duyệt/tên miền hoặc xóa bộ nhớ.

## Cấu trúc ZIP
- `index.html`: web tự chứa, chạy offline.
- `app.js`: mã JavaScript tham khảo để tùy biến.
- `questions.json`: dữ liệu trắc nghiệm.
- `README.md`: hướng dẫn này.

Ứng dụng chạy phía máy khách, không tích hợp OpenAI API ở bản này và không yêu cầu API key.
